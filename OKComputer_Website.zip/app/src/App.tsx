import { useState, useCallback } from 'react';
import { Copy, RefreshCw, Zap, Mic, Play, Brain, Lock, Image, Video, Film, Layers } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

// Types
interface Course {
  name: string;
  color: string;
  icon: string;
  psychology: {
    primary: string;
    triggers: string[];
    pain: string;
  };
  formulas: Formula[];
  templates: Template[];
}

interface Formula {
  name: string;
  template: string;
  psychology: string;
  trigger: string;
}

interface Template {
  title: string;
  hook: string;
  duration: string;
  viralScore: number;
}

interface ScriptSection {
  time: string;
  text: string;
  visual: string;
  audio: string;
  intensity: string;
}

interface GeneratedContent {
  hook: string;
  psychology: string;
  trigger: string;
  sections: ScriptSection[];
  cta: string;
  caption: string;
  hashtags: string;
  duration: string;
  wordCount: number;
}

// Course Data
const courseData: Record<string, Course> = {
  youtube: {
    name: 'YouTube Automation',
    color: 'red',
    icon: '▶',
    psychology: {
      primary: 'Freedom/Passive Income',
      triggers: ['FOMO', 'Social Proof', 'Authority'],
      pain: 'Trading time for money, burnout'
    },
    formulas: [
      { name: 'The Freedom Formula', template: 'I quit my job in {timeframe} using this {topic} system. Here is the exact blueprint:', psychology: 'Transformation/Identity', trigger: 'Pattern Interrupt' },
      { name: 'Mistake Reveal', template: 'The {number} mistakes killing your {topic} (Number {hidden} cost me $10,000)', psychology: 'Loss Aversion', trigger: 'Fear' },
      { name: 'Curiosity Gap', template: 'This {topic} loophole makes $X while you sleep. Most creators do not know it exists:', psychology: 'Information Gap', trigger: 'Curiosity' },
      { name: 'Contrarian Truth', template: 'Stop {common_belief}. I grew to {big_number} using this {unconventional_method} instead:', psychology: 'Reactance', trigger: 'Controversy' }
    ],
    templates: [
      { title: 'AI Voiceover Empire', hook: 'This AI voice makes $5K/month', duration: '30s', viralScore: 95 },
      { title: 'Thumbnail Psychology', hook: 'Why 99% of thumbnails fail', duration: '45s', viralScore: 92 },
      { title: 'Automation Workflow', hook: 'I automated my entire channel in 24hrs', duration: '60s', viralScore: 88 },
      { title: 'Niche Domination', hook: 'The untapped niche with 0 competition', duration: '90s', viralScore: 90 }
    ]
  },
  prompts: {
    name: '7 AI Prompts',
    color: 'purple',
    icon: '🧠',
    psychology: {
      primary: 'Knowledge/Power',
      triggers: ['Curiosity', 'Exclusivity', 'Quick Wins'],
      pain: 'Getting bad AI outputs, wasting time'
    },
    formulas: [
      { name: 'Secret Weapon', template: 'This {topic} prompt made me ${amount} in {timeframe}. Copy it exactly:', psychology: 'Exclusivity', trigger: 'FOMO' },
      { name: 'Before-After Shock', template: 'My ChatGPT was useless until I discovered the {framework_name} framework. Now it is like having a PhD assistant:', psychology: 'Transformation', trigger: 'Contrast' },
      { name: 'The Cheat Code', template: 'Stop typing prompts like a beginner. Use this {topic} cheat code instead (99% do not know this):', psychology: 'Superiority', trigger: 'Insider Knowledge' },
      { name: 'Result Guarantee', template: 'Try this {topic} prompt once. You will never go back to the old way:', psychology: 'Low Risk', trigger: 'Challenge' }
    ],
    templates: [
      { title: 'Midjourney Mastery', hook: 'This prompt creates $500 images', duration: '30s', viralScore: 94 },
      { title: 'Code Generator', hook: 'Write entire apps with one prompt', duration: '45s', viralScore: 91 },
      { title: 'Copywriting AI', hook: 'This prompt writes better than humans', duration: '60s', viralScore: 89 },
      { title: 'ChatGPT Hacks', hook: '10X your output with this secret', duration: '30s', viralScore: 93 }
    ]
  },
  ceh: {
    name: 'CEH Course',
    color: 'green',
    icon: '🔒',
    psychology: {
      primary: 'Security/Power',
      triggers: ['Fear', 'Curiosity', 'Protection'],
      pain: 'Being vulnerable, hacked, ignorant'
    },
    formulas: [
      { name: 'Vulnerability Alert', template: 'Your {device} is vulnerable to {attack_type} RIGHT NOW. Here is how to protect yourself in {timeframe}:', psychology: 'Fear/Protection', trigger: 'Urgency' },
      { name: 'Insider Secret', template: 'Hackers do not want you to know this {technique}. I should not be showing you this:', psychology: 'Taboo/Forbidden', trigger: 'Curiosity' },
      { name: 'Transformation Story', template: 'From zero to ethical hacker in {timeframe}. This is the exact roadmap (no degree needed):', psychology: 'Transformation', trigger: 'Hope' },
      { name: 'Myth Busting', template: 'Everything you know about {security_topic} is wrong. Here is what actually works:', psychology: 'Cognitive Dissonance', trigger: 'Controversy' }
    ],
    templates: [
      { title: 'WiFi Hacking', hook: 'Crack any WiFi in 2 minutes (legal)', duration: '60s', viralScore: 96 },
      { title: 'Phishing Detection', hook: 'This email could steal your life savings', duration: '45s', viralScore: 94 },
      { title: 'Dark Web Access', hook: 'I accessed the dark web so you do not have to', duration: '90s', viralScore: 92 },
      { title: 'Phone Hacking', hook: 'Your phone is spying on you (proof)', duration: '60s', viralScore: 95 }
    ]
  }
};

const algorithm2025: Record<string, { tips: string[] }> = {
  reel: {
    tips: [
      'Post at 9AM, 12PM, or 6PM for peak engagement',
      'First 1-2 seconds decide scroll or stay',
      'Use high-contrast burned-in captions',
      'End with open loop or CTA for comments',
      'Reply to comments in first hour to boost reach'
    ]
  },
  short: {
    tips: [
      'Loop-friendly content (seamless restart)',
      'Use trending sounds but edit uniquely',
      'Vertical 9:16 format mandatory',
      'Pattern interrupt in first 3 seconds',
      'Pinned comment with CTA within 30 mins'
    ]
  },
  long: {
    tips: [
      'Hook must preview the payoff',
      'Chapter markers for retention',
      'End screen with next video suggestion',
      'Thumbnail A/B testing crucial',
      'First 30 seconds = 50% of retention'
    ]
  },
  carousel: {
    tips: [
      'First slide is the hook (like a thumbnail)',
      'Last slide = strong CTA',
      'Design for mobile viewing',
      'Use carousel for educational content',
      'Saves indicate high value to algorithm'
    ]
  }
};

export default function App() {
  const [currentCourse, setCurrentCourse] = useState('youtube');
  const [currentType, setCurrentType] = useState('reel');
  const [showVoicePanel, setShowVoicePanel] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent | null>(null);
  const [viralScore, setViralScore] = useState(92);
  const [hookMetric, setHookMetric] = useState(95);
  const [retentionMetric, setRetentionMetric] = useState(88);
  const [shareMetric, setShareMetric] = useState(91);
  
  // Form inputs
  const [topic, setTopic] = useState('');
  const [painPoint, setPainPoint] = useState('');
  const [emotion, setEmotion] = useState('curiosity');
  const [angle, setAngle] = useState('how-to');
  const [voice, setVoice] = useState('energetic');

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard!');
  };

  const generateStep = (index: number, topicStr: string, angleStr: string): string => {
    const steps: Record<string, string[]> = {
      'how-to': [
        `Identify the ${topicStr} pattern that 99% miss`,
        `Apply the "3-Second Rule" for instant results`,
        `Automate using the AI stack I mentioned`,
        `Scale what works, kill what doesn't`,
        `Monetize through multiple revenue streams`
      ],
      'listicle': [
        `The first ${topicStr} mistake is being too broad`,
        `Second: Ignoring the algorithm's preference`,
        `Third: Not using AI to amplify output`,
        `Fourth: Forgetting the emotional hook`,
        `Fifth: Missing the monetization window`
      ],
      'story': [
        `I was broke and desperate when I found this`,
        `The first ${topicStr} attempt failed miserably`,
        `Then I discovered the pattern that changed everything`,
        `Now I scale this system across multiple channels`,
        `You can replicate this starting today`
      ],
      'controversial': [
        `Everything gurus tell you about ${topicStr} is wrong`,
        `The real money is in the opposite approach`,
        `I proved this by going against the crowd`,
        `The data shows this method outperforms by 10x`,
        `Yet most creators are too scared to try it`
      ],
      'behind-scenes': [
        `Here is my actual ${topicStr} dashboard`,
        `These are the real numbers nobody shows`,
        `I spend 2 hours per week on this now`,
        `The system runs itself while I sleep`,
        `This is the infrastructure behind the success`
      ]
    };
    const list = steps[angleStr] || steps['how-to'];
    return list[index % list.length];
  };

  const getVisual = (index: number): string => {
    const visuals = [
      'Screen recording with cursor highlights',
      'Stock footage (fast-paced, relevant)',
      'Text animation with kinetic typography',
      'Split screen comparison (before/after)',
      'Emoji overlay and graphics',
      'B-roll of success/lifestyle',
      'Data visualization/charts',
      'Faceless creator hands typing'
    ];
    return visuals[index % visuals.length];
  };

  const getAudio = (index: number): string => {
    const audios = [
      'Keyboard typing ASMR',
      'Whoosh transition SFX',
      'Deep bass hit',
      'Notification chime',
      'Suspense riser',
      'Digital glitch sound',
      'Success chime',
      'Paper tear sound'
    ];
    return audios[index % audios.length];
  };

  const generateContent = useCallback(() => {
    setIsGenerating(true);
    
    setTimeout(() => {
      const course = courseData[currentCourse];
      const formulas = course.formulas;
      const formula = formulas[Math.floor(Math.random() * formulas.length)];
      
      const variables: Record<string, string> = {
        timeframe: ['30 days', '24 hours', '7 days', '90 days', '6 months'][Math.floor(Math.random() * 5)],
        amount: ['$10,000', '$50,000', '$100K', '$1M', 'six figures'][Math.floor(Math.random() * 5)],
        number: ['3', '5', '7', '10'][Math.floor(Math.random() * 4)],
        hidden: ['3', '5', '7'][Math.floor(Math.random() * 3)],
        device: ['phone', 'laptop', 'WiFi', 'email'][Math.floor(Math.random() * 4)],
        attack_type: ['phishing', 'malware', 'hacking', 'data breach'][Math.floor(Math.random() * 4)],
        common_belief: ['posting daily', 'using hashtags', 'following trends', 'buying ads'][Math.floor(Math.random() * 4)],
        big_number: ['100K', '1M', '10M', '100M'][Math.floor(Math.random() * 4)],
        unconventional_method: ['AI automation', 'faceless strategy', 'repurposing content', 'controversial takes'][Math.floor(Math.random() * 4)],
        framework_name: ['PECRA', 'CHAIN', 'STAR', 'RPG'][Math.floor(Math.random() * 4)],
        technique: ['social engineering', 'zero-day exploit', 'brute force', 'MITM attack'][Math.floor(Math.random() * 4)]
      };
      
      let hook = formula.template;
      Object.keys(variables).forEach(key => {
        hook = hook.replace(`{${key}}`, variables[key]);
      });
      hook = hook.replace('{topic}', topic || 'AI Content Creation');
      
      const duration = currentType === 'reel' ? 30 : currentType === 'short' ? 45 : currentType === 'carousel' ? 60 : 180;
      const sections: ScriptSection[] = [];
      
      sections.push({
        time: '0-3s',
        text: hook,
        visual: 'Text overlay with glitch effect, fast zoom',
        audio: 'Hard bass drop + silence',
        intensity: 'high'
      });
      
      sections.push({
        time: '3-8s',
        text: `You are ${painPoint || 'wasting time on manual work'}. Everyone told you it takes years to master ${topic || 'AI Content Creation'}. They lied to keep you small.`,
        visual: 'Frustrated stock footage, red tint, fast cuts',
        audio: 'Tension building, heart beat',
        intensity: 'medium'
      });
      
      sections.push({
        time: '8-15s',
        text: `I discovered a ${topic || 'AI Content Creation'} system that changes everything. Here is the exact framework nobody talks about:`,
        visual: 'Screen recording, glowing highlights, UI zoom',
        audio: 'Notification chimes, tech sounds',
        intensity: 'medium'
      });
      
      const steps = Math.floor((duration - 30) / 15);
      for (let i = 0; i < steps; i++) {
        sections.push({
          time: `${15 + (i * 15)}-${30 + (i * 15)}s`,
          text: `Step ${i + 1}: ${generateStep(i, topic || 'AI Content Creation', angle)}`,
          visual: `${getVisual(i)}, smooth transition`,
          audio: getAudio(i),
          intensity: i % 2 === 0 ? 'high' : 'medium'
        });
      }
      
      const ctas: Record<string, string[]> = {
        youtube: ['Link in bio for the complete automation blueprint', 'Comment "SYSTEM" to get my workflow', 'Follow for part 2 (you need to see this)'],
        prompts: ['Comment "PROMPT" to get my 7 secret frameworks', 'Save this before it gets deleted', 'Share with someone who needs this'],
        ceh: ['Follow for daily security tips (legally)', 'Comment "SECURE" for my protection checklist', 'Link in bio for the full CEH course']
      };
      const cta = ctas[currentCourse][Math.floor(Math.random() * 3)];
      
      sections.push({
        time: `${duration - 10}s`,
        text: cta,
        visual: 'Profile highlight, follow button pulse, arrow pointing',
        audio: 'Inspirational outro music swells',
        intensity: 'high'
      });
      
      const captions: Record<string, string> = {
        youtube: `🚀 ${topic || 'AI Content Creation'} changed my life.\n\nWhich part hit harder? 👇\n\nSave this for later ⚡`,
        prompts: `🧠 This ${topic || 'AI Content Creation'} prompt is worth $10,000.\n\nMost people will scroll past this. Will you? 🤔\n\nDrop a 🔥 if you want more`,
        ceh: `🔒 Your ${topic || 'AI Content Creation'} security is at risk.\n\nShare this to protect someone you care about.\n\nStay safe out there 🛡️`
      };
      
      const hashtags: Record<string, string> = {
        youtube: '#YouTubeAutomation #FacelessChannel #PassiveIncome #ContentCreator #AI #ViralContent',
        prompts: '#AIPrompts #ChatGPT #Midjourney #PromptEngineering #AIHacks #ChatGPTTips',
        ceh: '#EthicalHacking #CyberSecurity #CEH #Hacking #InfoSec #CyberAttack'
      };
      
      setGeneratedContent({
        hook,
        psychology: formula.psychology,
        trigger: formula.trigger,
        sections,
        cta,
        caption: captions[currentCourse],
        hashtags: hashtags[currentCourse],
        duration: `${duration}s`,
        wordCount: sections.reduce((acc, s) => acc + s.text.split(' ').length, 0)
      });
      
      // Update viral scores
      const newHook = Math.floor(Math.random() * 10) + 90;
      const newRetention = Math.floor(Math.random() * 15) + 85;
      const newShare = Math.floor(Math.random() * 20) + 80;
      const total = Math.round((newHook + newRetention + newShare) / 3);
      
      setHookMetric(newHook);
      setRetentionMetric(newRetention);
      setShareMetric(newShare);
      setViralScore(total);
      
      setIsGenerating(false);
    }, 2000);
  }, [currentCourse, currentType, topic, painPoint, angle]);

  const applyFormula = (template: string, psych: string) => {
    setTopic(template);
    setEmotion(psych.toLowerCase().includes('fear') ? 'fear' : 
               psych.toLowerCase().includes('curiosity') ? 'curiosity' : 'awe');
  };

  const loadTemplate = (title: string, hook: string) => {
    setTopic(title);
    setPainPoint(hook);
    generateContent();
  };

  const batchGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      toast.success('Batch complete! 10 scripts generated.');
      setIsGenerating(false);
    }, 3000);
  };

  const course = courseData[currentCourse];

  return (
    <div className="min-h-screen relative">
      {/* Background Effects */}
      <div className="bg-grid" />
      <div className="orb orb-1" />
      <div className="orb orb-2" />
      <div className="orb orb-3" />
      
      {/* Main Container */}
      <div className="relative z-10 container mx-auto px-4 py-6 max-w-[1600px]">
        
        {/* Header */}
        <header className="flex justify-between items-center mb-8 glass-elite rounded-2xl p-6 gradient-border-elite">
          <div className="flex items-center gap-6">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-purple-600 blur-xl opacity-50" />
              <div className="relative font-elite text-4xl tracking-widest text-white">
                ANYMS<span className="text-cyan-400">_</span>AI
              </div>
            </div>
            <div className="h-12 w-px bg-gradient-to-b from-transparent via-cyan-500 to-transparent" />
            <div>
              <div className="text-xs text-gray-400 tracking-widest uppercase mb-1">Elite Content System</div>
              <div className="text-sm text-cyan-400 font-bold">v3.0.2025</div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right hidden md:block">
              <div className="text-xs text-gray-500">Algorithm Status</div>
              <div className="text-sm text-green-400 font-bold flex items-center gap-2">
                <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                2025 OPTIMIZED
              </div>
            </div>
            <Button 
              onClick={() => setShowVoicePanel(!showVoicePanel)}
              className="btn-elite px-4 py-2 rounded-lg text-sm font-bold text-white hover:text-cyan-400"
            >
              <Mic className="w-4 h-4 mr-2" />
              Voice AI
            </Button>
          </div>
        </header>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          
          {/* Left Panel: Strategy Hub */}
          <div className="xl:col-span-3 space-y-6">
            
            {/* Course Selector */}
            <div className="glass-elite rounded-2xl p-6 gradient-border-elite">
              <h3 className="font-cyber text-lg mb-4 text-cyan-400 flex items-center gap-2">
                <span className="w-2 h-2 bg-cyan-400 rounded-full" />
                SELECT NICHE
              </h3>
              <div className="space-y-3">
                <button 
                  onClick={() => setCurrentCourse('youtube')}
                  className={`course-btn w-full p-4 rounded-xl bg-gradient-to-r from-red-900/30 to-red-600/10 border border-red-500/30 hover:border-red-400 transition-all text-left group relative overflow-hidden ${currentCourse === 'youtube' ? 'ring-2 ring-cyan-400' : 'opacity-70'}`}
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-red-500/0 to-red-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="relative flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-red-500/20 flex items-center justify-center text-2xl group-hover:scale-110 transition-transform border border-red-500/30">
                      <Play className="w-6 h-6 text-red-400" />
                    </div>
                    <div>
                      <div className="font-bold text-red-400 group-hover:text-red-300">YouTube Automation</div>
                      <div className="text-xs text-gray-500 mt-1">Faceless Empire Builder</div>
                    </div>
                  </div>
                </button>
                
                <button 
                  onClick={() => setCurrentCourse('prompts')}
                  className={`course-btn w-full p-4 rounded-xl bg-gradient-to-r from-purple-900/30 to-purple-600/10 border border-purple-500/30 hover:border-purple-400 transition-all text-left group relative overflow-hidden ${currentCourse === 'prompts' ? 'ring-2 ring-cyan-400' : 'opacity-70'}`}
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-purple-500/0 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="relative flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center text-2xl group-hover:scale-110 transition-transform border border-purple-500/30">
                      <Brain className="w-6 h-6 text-purple-400" />
                    </div>
                    <div>
                      <div className="font-bold text-purple-400 group-hover:text-purple-300">7 AI Prompts</div>
                      <div className="text-xs text-gray-500 mt-1">Prompt Engineering Mastery</div>
                    </div>
                  </div>
                </button>
                
                <button 
                  onClick={() => setCurrentCourse('ceh')}
                  className={`course-btn w-full p-4 rounded-xl bg-gradient-to-r from-green-900/30 to-green-600/10 border border-green-500/30 hover:border-green-400 transition-all text-left group relative overflow-hidden ${currentCourse === 'ceh' ? 'ring-2 ring-cyan-400' : 'opacity-70'}`}
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-green-500/0 to-green-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="relative flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-green-500/20 flex items-center justify-center text-2xl group-hover:scale-110 transition-transform border border-green-500/30">
                      <Lock className="w-6 h-6 text-green-400" />
                    </div>
                    <div>
                      <div className="font-bold text-green-400 group-hover:text-green-300">CEH Course</div>
                      <div className="text-xs text-gray-500 mt-1">Ethical Hacking Pro</div>
                    </div>
                  </div>
                </button>
              </div>
            </div>

            {/* Viral Score Card */}
            <div className="glass-elite rounded-2xl p-6 gradient-border-elite">
              <h3 className="font-cyber text-lg mb-4 text-purple-400">VIRAL POTENTIAL SCORE</h3>
              <div className="flex justify-center mb-6">
                <div className="score-ring" style={{ '--score': `${viralScore}%` } as React.CSSProperties}>
                  <span className="score-value">{viralScore}</span>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Hook Strength</span>
                    <span className="text-cyan-400 font-bold">{hookMetric}%</span>
                  </div>
                  <div className="progress-elite">
                    <div className="progress-fill" style={{ width: `${hookMetric}%` }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Retention Prediction</span>
                    <span className="text-purple-400 font-bold">{retentionMetric}%</span>
                  </div>
                  <div className="progress-elite">
                    <div className="progress-fill" style={{ width: `${retentionMetric}%`, background: 'linear-gradient(90deg, #bc13fe, #ff006e)' }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Shareability</span>
                    <span className="text-pink-400 font-bold">{shareMetric}%</span>
                  </div>
                  <div className="progress-elite">
                    <div className="progress-fill" style={{ width: `${shareMetric}%`, background: 'linear-gradient(90deg, #ff006e, #ff4d00)' }} />
                  </div>
                </div>
              </div>
            </div>

            {/* AI Voice Settings Panel */}
            {showVoicePanel && (
              <div className="glass-elite rounded-2xl p-6 gradient-border-elite">
                <h3 className="font-cyber text-lg mb-4 text-yellow-400 flex items-center gap-2">
                  <Mic className="w-5 h-5" />
                  AI VOICE CONFIG
                </h3>
                <div className="space-y-3 text-sm">
                  <div className="p-3 rounded-lg bg-black/30 border border-yellow-500/20">
                    <div className="text-yellow-400 font-bold mb-1">ElevenLabs</div>
                    <div className="text-gray-500 text-xs">Best for English narration</div>
                    <div className="mt-2 flex gap-2">
                      <span className="px-2 py-1 bg-yellow-500/20 text-yellow-400 text-xs rounded">Human-like</span>
                      <span className="px-2 py-1 bg-yellow-500/20 text-yellow-400 text-xs rounded">Multilingual</span>
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-black/30 border border-cyan-500/20">
                    <div className="text-cyan-400 font-bold mb-1">Fish Audio</div>
                    <div className="text-gray-500 text-xs">Emotional control & diversity</div>
                    <div className="mt-2 flex gap-2">
                      <span className="px-2 py-1 bg-cyan-500/20 text-cyan-400 text-xs rounded">Emotions</span>
                      <span className="px-2 py-1 bg-cyan-500/20 text-cyan-400 text-xs rounded">Fast clone</span>
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-black/30 border border-purple-500/20">
                    <div className="text-purple-400 font-bold mb-1">Descript Overdub</div>
                    <div className="text-gray-500 text-xs">Edit audio like text</div>
                    <div className="mt-2 flex gap-2">
                      <span className="px-2 py-1 bg-purple-500/20 text-purple-400 text-xs rounded">Edit</span>
                      <span className="px-2 py-1 bg-purple-500/20 text-purple-400 text-xs rounded">Podcast</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Center Panel: Generation Engine */}
          <div className="xl:col-span-6 space-y-6">
            
            {/* Content Type Selector */}
            <div className="glass-elite rounded-2xl p-2 flex gap-2 overflow-x-auto">
              <button 
                onClick={() => setCurrentType('reel')}
                className={`tab-elite flex-1 py-4 px-6 rounded-xl font-bold text-sm transition-all ${currentType === 'reel' ? 'active' : 'text-gray-400'}`}
              >
                <div className="flex flex-col items-center gap-1">
                  <Image className="w-5 h-5" />
                  <span>INSTAGRAM REEL</span>
                  <span className="text-[10px] opacity-60 font-normal">0-30s | Vertical</span>
                </div>
              </button>
              <button 
                onClick={() => setCurrentType('short')}
                className={`tab-elite flex-1 py-4 px-6 rounded-xl font-bold text-sm transition-all ${currentType === 'short' ? 'active' : 'text-gray-400'}`}
              >
                <div className="flex flex-col items-center gap-1">
                  <Play className="w-5 h-5" />
                  <span>YT SHORT</span>
                  <span className="text-[10px] opacity-60 font-normal">15-60s | Loop</span>
                </div>
              </button>
              <button 
                onClick={() => setCurrentType('long')}
                className={`tab-elite flex-1 py-4 px-6 rounded-xl font-bold text-sm transition-all ${currentType === 'long' ? 'active' : 'text-gray-400'}`}
              >
                <div className="flex flex-col items-center gap-1">
                  <Film className="w-5 h-5" />
                  <span>LONG VIDEO</span>
                  <span className="text-[10px] opacity-60 font-normal">3-10min | Story</span>
                </div>
              </button>
              <button 
                onClick={() => setCurrentType('carousel')}
                className={`tab-elite flex-1 py-4 px-6 rounded-xl font-bold text-sm transition-all ${currentType === 'carousel' ? 'active' : 'text-gray-400'}`}
              >
                <div className="flex flex-col items-center gap-1">
                  <Layers className="w-5 h-5" />
                  <span>CAROUSEL</span>
                  <span className="text-[10px] opacity-60 font-normal">5-10 slides | Save</span>
                </div>
              </button>
            </div>

            {/* Main Generator */}
            <div className="glass-elite rounded-2xl p-8 gradient-border-elite relative overflow-hidden min-h-[600px]">
              <div className="neural-bg">
                {Array.from({ length: 20 }).map((_, i) => (
                  <div 
                    key={i} 
                    className="node" 
                    style={{ 
                      left: `${Math.random() * 100}%`, 
                      top: `${Math.random() * 100}%`,
                      animationDelay: `${Math.random() * 3}s` 
                    }} 
                  />
                ))}
              </div>
            
              <div className="relative z-10">
                <div className="flex justify-between items-start mb-8">
                  <div>
                    <h2 className="font-cyber text-3xl mb-2 text-gradient">NEURAL CONTENT ENGINE</h2>
                    <p className="text-gray-400 text-sm">Generate {course.psychology.primary}-driven viral content for {course.name}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      onClick={batchGenerate}
                      className="btn-elite px-4 py-2 rounded-lg text-sm font-bold text-cyan-400 border border-cyan-500/30"
                    >
                      <Zap className="w-4 h-4 mr-2" />
                      Batch (10x)
                    </Button>
                  </div>
                </div>

                {/* Smart Input System */}
                <div className="space-y-4 mb-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="relative">
                      <label className="block text-xs font-bold text-cyan-400 mb-2 tracking-wider">TOPIC / NICHE</label>
                      <input 
                        type="text" 
                        value={topic}
                        onChange={(e) => setTopic(e.target.value)}
                        placeholder="e.g., AI Thumbnails that get 10M views" 
                        className="input-elite w-full rounded-xl px-4 py-4 text-white placeholder-gray-600 font-medium"
                      />
                    </div>
                    <div className="relative">
                      <label className="block text-xs font-bold text-purple-400 mb-2 tracking-wider">PAIN POINT / DESIRE</label>
                      <input 
                        type="text" 
                        value={painPoint}
                        onChange={(e) => setPainPoint(e.target.value)}
                        placeholder="e.g., Spending 20hrs editing per video" 
                        className="input-elite w-full rounded-xl px-4 py-4 text-white placeholder-gray-600 font-medium"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-pink-400 mb-2 tracking-wider">TARGET EMOTION</label>
                      <select 
                        value={emotion}
                        onChange={(e) => setEmotion(e.target.value)}
                        className="input-elite w-full rounded-xl px-4 py-3 text-white bg-black/50"
                      >
                        <option value="curiosity">🔍 Curiosity (Best for saves)</option>
                        <option value="fear">😰 Fear (High engagement)</option>
                        <option value="awe">🤯 Awe (Shareable)</option>
                        <option value="anger">😤 Anger (Comments)</option>
                        <option value="joy">🎉 Joy (Broad appeal)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-yellow-400 mb-2 tracking-wider">CONTENT ANGLE</label>
                      <select 
                        value={angle}
                        onChange={(e) => setAngle(e.target.value)}
                        className="input-elite w-full rounded-xl px-4 py-3 text-white bg-black/50"
                      >
                        <option value="how-to">How-To (Educational)</option>
                        <option value="listicle">Listicle (X Ways)</option>
                        <option value="story">Story (Transformation)</option>
                        <option value="controversial">Contrarian (Myth-busting)</option>
                        <option value="behind-scenes">BTS (Insider)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-green-400 mb-2 tracking-wider">VOICE STYLE</label>
                      <select 
                        value={voice}
                        onChange={(e) => setVoice(e.target.value)}
                        className="input-elite w-full rounded-xl px-4 py-3 text-white bg-black/50"
                      >
                        <option value="energetic">⚡ Energetic (Hype)</option>
                        <option value="calm">🧘 Calm (ASMR-style)</option>
                        <option value="authority">🎓 Authority (Expert)</option>
                        <option value="conversational">💬 Conversational (Friend)</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Viral Formula Lab */}
                <div className="mb-8">
                  <div className="flex justify-between items-center mb-4">
                    <label className="text-xs font-bold text-pink-400 tracking-wider">NEUROSCIENCE HOOK FORMULAS</label>
                    <span className="text-xs text-gray-500">Click to apply</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {course.formulas.map((formula, i) => (
                      <div 
                        key={i}
                        onClick={() => applyFormula(formula.template, formula.psychology)}
                        className="cursor-pointer p-4 rounded-xl border border-gray-800 hover:border-cyan-500/50 transition-all hover:bg-cyan-500/5 group relative overflow-hidden"
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/0 to-cyan-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                        <div className="relative">
                          <div className="flex justify-between items-start mb-2">
                            <span className="text-xs font-bold text-cyan-400">FORMULA {i + 1}</span>
                            <span className="text-[10px] px-2 py-1 rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/30">{formula.psychology}</span>
                          </div>
                          <div className="text-sm font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors">{formula.name}</div>
                          <div className="text-xs text-gray-500 line-clamp-2">{formula.template}</div>
                          <div className="mt-2 flex items-center gap-2">
                            <span className="text-[10px] px-2 py-0.5 rounded bg-pink-500/10 text-pink-400">{formula.trigger}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Generate Button */}
                <button 
                  onClick={generateContent}
                  disabled={isGenerating}
                  className="w-full btn-gold py-5 rounded-xl font-cyber text-lg font-bold text-yellow-400 border border-yellow-500/50 relative overflow-hidden group disabled:opacity-50"
                >
                  <span className="relative z-10 flex items-center justify-center gap-3">
                    {isGenerating ? (
                      <div className="loader" />
                    ) : (
                      <>
                        <span className="text-2xl">🚀</span>
                        GENERATE VIRAL CONTENT SYSTEM
                        <span className="text-xs opacity-60 font-normal bg-black/30 px-2 py-1 rounded">2025 ALGORITHM OPTIMIZED</span>
                      </>
                    )}
                  </span>
                  <div className="absolute inset-0 bg-gradient-to-r from-yellow-500/0 via-yellow-500/20 to-yellow-500/0 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
                </button>

                {/* Output Section */}
                {generatedContent && (
                  <div className="mt-8 space-y-6">
                    
                    {/* Hook Card */}
                    <div className="relative p-6 rounded-xl bg-gradient-to-r from-pink-900/20 to-purple-900/20 border border-pink-500/30">
                      <div className="absolute -top-3 left-6 bg-pink-500 text-black text-xs font-bold px-4 py-1 rounded-full flex items-center gap-1">
                        <Zap className="w-3 h-3" />
                        VIRAL HOOK (0-3 SEC)
                      </div>
                      <p className="text-xl font-bold text-white mt-2 leading-relaxed">{generatedContent.hook}</p>
                      <div className="flex gap-2 mt-4">
                        <span className="text-xs px-2 py-1 rounded bg-pink-500/20 text-pink-400 border border-pink-500/30">{generatedContent.psychology}</span>
                        <span className="text-xs px-2 py-1 rounded bg-purple-500/20 text-purple-400 border border-purple-500/30">{generatedContent.trigger}</span>
                      </div>
                      <button 
                        onClick={() => copyToClipboard(generatedContent.hook)}
                        className="absolute top-4 right-4 text-pink-400 hover:text-white transition-colors p-2 hover:bg-white/5 rounded-lg"
                      >
                        <Copy className="w-5 h-5" />
                      </button>
                    </div>

                    {/* Full Script */}
                    <div className="glass-elite rounded-xl p-6 border border-gray-700/50">
                      <div className="flex justify-between items-center mb-6">
                        <div className="flex items-center gap-3">
                          <h3 className="font-cyber text-lg text-cyan-400">COMPLETE SCRIPT</h3>
                          <span className="text-xs px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">{generatedContent.duration}</span>
                          <span className="text-xs px-3 py-1 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/30">{generatedContent.wordCount} words</span>
                        </div>
                        <div className="flex gap-2">
                          <Button 
                            onClick={generateContent}
                            className="btn-elite px-3 py-2 rounded-lg text-xs font-bold text-cyan-400"
                          >
                            <RefreshCw className="w-4 h-4 mr-1" />
                            Regenerate
                          </Button>
                          <Button 
                            onClick={() => copyToClipboard(generatedContent.sections.map(s => s.text).join('\n\n'))}
                            className="btn-elite px-3 py-2 rounded-lg text-xs font-bold text-cyan-400"
                          >
                            <Copy className="w-4 h-4 mr-1" />
                            Copy All
                          </Button>
                        </div>
                      </div>
                      <div className="space-y-4 text-gray-300 leading-relaxed">
                        {generatedContent.sections.map((section, i) => (
                          <div key={i} className="flex gap-4 p-4 rounded-xl bg-black/20 border border-gray-800 hover:border-cyan-500/30 transition-all group">
                            <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-cyan-500/20 to-purple-500/20 flex flex-col items-center justify-center flex-shrink-0 border border-cyan-500/20">
                              <span className="text-xs text-cyan-400 font-bold">{section.time}</span>
                              <span className="text-[10px] text-gray-500">{section.intensity}</span>
                            </div>
                            <div className="flex-1">
                              <p className="text-white font-medium mb-3 leading-relaxed">{section.text}</p>
                              <div className="flex flex-wrap gap-2">
                                <span className="text-[10px] px-2 py-1 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20 flex items-center gap-1">
                                  <Video className="w-3 h-3" />
                                  {section.visual}
                                </span>
                                <span className="text-[10px] px-2 py-1 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 flex items-center gap-1">
                                  <Mic className="w-3 h-3" />
                                  {section.audio}
                                </span>
                              </div>
                            </div>
                            <button 
                              onClick={() => copyToClipboard(section.text)}
                              className="opacity-0 group-hover:opacity-100 transition-opacity text-gray-500 hover:text-cyan-400 self-start p-2"
                            >
                              <Copy className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Production Guide */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="glass-elite rounded-xl p-6 border border-purple-500/30">
                        <h3 className="font-cyber text-sm text-purple-400 mb-4 flex items-center gap-2">
                          <Video className="w-4 h-4" />
                          VISUAL DIRECTIONS
                        </h3>
                        <div className="space-y-3 text-sm">
                          {generatedContent.sections.map((s, i) => (
                            <div key={i} className="flex items-start gap-2 text-xs">
                              <span className="text-purple-400 font-bold">{i + 1}.</span>
                              <span className="text-gray-400">{s.visual}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      <div className="glass-elite rounded-xl p-6 border border-cyan-500/30">
                        <h3 className="font-cyber text-sm text-cyan-400 mb-4 flex items-center gap-2">
                          <Mic className="w-4 h-4" />
                          AUDIO & SFX
                        </h3>
                        <div className="space-y-3 text-sm">
                          {generatedContent.sections.map((s, i) => (
                            <div key={i} className="flex items-start gap-2 text-xs">
                              <span className="text-cyan-400 font-bold">{i + 1}.</span>
                              <span className="text-gray-400">{s.audio}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* CTA & Distribution */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="glass-elite rounded-xl p-5 border border-yellow-500/30">
                        <h3 className="font-cyber text-xs text-yellow-400 mb-2">CALL TO ACTION</h3>
                        <p className="text-white font-bold text-sm">{generatedContent.cta}</p>
                      </div>
                      <div className="glass-elite rounded-xl p-5 border border-green-500/30">
                        <h3 className="font-cyber text-xs text-green-400 mb-2">CAPTION</h3>
                        <p className="text-gray-400 text-xs leading-relaxed whitespace-pre-line">{generatedContent.caption}</p>
                      </div>
                      <div className="glass-elite rounded-xl p-5 border border-pink-500/30">
                        <h3 className="font-cyber text-xs text-pink-400 mb-2">HASHTAGS</h3>
                        <p className="text-gray-400 text-xs">{generatedContent.hashtags}</p>
                      </div>
                    </div>

                    {/* 2025 Algorithm Tips */}
                    <div className="glass-elite rounded-xl p-6 border border-cyan-500/20 bg-cyan-900/10">
                      <h3 className="font-cyber text-sm text-cyan-400 mb-3 flex items-center gap-2">
                        <Brain className="w-4 h-4" />
                        2025 ALGORITHM OPTIMIZATION TIPS
                      </h3>
                      <ul className="space-y-2 text-xs text-gray-400">
                        {algorithm2025[currentType].tips.map((tip, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-cyan-400 mt-0.5">▸</span>
                            <span>{tip}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}

                {/* Empty State */}
                {!generatedContent && (
                  <div className="text-center py-20">
                    <div className="w-32 h-32 mx-auto mb-6 relative">
                      <div className="absolute inset-0 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-full blur-2xl opacity-30 animate-pulse" />
                      <div className="relative w-full h-full rounded-full bg-black/50 border border-cyan-500/30 flex items-center justify-center">
                        <span className="text-5xl">🚀</span>
                      </div>
                    </div>
                    <h3 className="font-cyber text-xl text-white mb-2">Ready to Generate Viral Content</h3>
                    <p className="text-gray-500 text-sm max-w-md mx-auto">Enter your topic and pain point above, then click the gold button to create algorithm-optimized content for your selected course.</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Panel: Intelligence Hub */}
          <div className="xl:col-span-3 space-y-6">
            
            {/* Trending Templates */}
            <div className="glass-elite rounded-2xl p-6 gradient-border-elite">
              <h3 className="font-cyber text-lg mb-4 text-yellow-400 flex items-center gap-2">
                <span className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse" />
                VIRAL TEMPLATES
              </h3>
              <div className="space-y-3">
                {course.templates.map((t, i) => (
                  <div 
                    key={i}
                    onClick={() => loadTemplate(t.title, t.hook)}
                    className="card-hover cursor-pointer p-4 rounded-xl bg-black/40 border border-gray-800 relative overflow-hidden group"
                  >
                    <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-cyan-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-xs text-gray-500">{t.duration}</span>
                      <span className="text-xs font-bold text-green-400">{t.viralScore}% viral</span>
                    </div>
                    <h4 className="font-bold text-white text-sm mb-1 group-hover:text-cyan-400 transition-colors">{t.title}</h4>
                    <p className="text-xs text-gray-500 italic">"{t.hook}"</p>
                    <div className="mt-3 flex gap-2">
                      <button className="text-[10px] px-2 py-1 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 hover:bg-cyan-500/20 transition-colors">Use Template</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* AI Tool Stack */}
            <div className="glass-elite rounded-2xl p-6 gradient-border-elite">
              <h3 className="font-cyber text-lg mb-4 text-cyan-400">RECOMMENDED AI STACK</h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-center gap-3 p-3 rounded-lg bg-black/30 border border-gray-800 hover:border-cyan-500/30 transition-colors cursor-pointer group">
                  <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center text-purple-400 group-hover:scale-110 transition-transform">
                    <Mic className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <div className="font-bold text-white">ElevenLabs</div>
                    <div className="text-xs text-gray-500">Voice Generation</div>
                  </div>
                  <div className="text-xs text-cyan-400">#1</div>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-black/30 border border-gray-800 hover:border-cyan-500/30 transition-colors cursor-pointer group">
                  <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
                    <Video className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <div className="font-bold text-white">HeyGen</div>
                    <div className="text-xs text-gray-500">AI Avatars</div>
                  </div>
                  <div className="text-xs text-cyan-400">HOT</div>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-black/30 border border-gray-800 hover:border-cyan-500/30 transition-colors cursor-pointer group">
                  <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center text-green-400 group-hover:scale-110 transition-transform">
                    <Layers className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <div className="font-bold text-white">CapCut</div>
                    <div className="text-xs text-gray-500">Auto Editing</div>
                  </div>
                  <div className="text-xs text-cyan-400">FREE</div>
                </div>
              </div>
            </div>

            {/* Content Calendar */}
            <div className="glass-elite rounded-2xl p-6 gradient-border-elite">
              <h3 className="font-cyber text-lg mb-4 text-pink-400">POSTING STRATEGY</h3>
              <div className="space-y-3 text-xs">
                <div className="flex justify-between items-center p-3 rounded-lg bg-black/30 border border-gray-800">
                  <div>
                    <div className="text-white font-bold">Instagram Reels</div>
                    <div className="text-gray-500">3-5x per day</div>
                  </div>
                  <div className="text-right">
                    <div className="text-green-400 font-bold">9AM, 12PM, 6PM</div>
                    <div className="text-gray-600">Peak engagement</div>
                  </div>
                </div>
                <div className="flex justify-between items-center p-3 rounded-lg bg-black/30 border border-gray-800">
                  <div>
                    <div className="text-white font-bold">YT Shorts</div>
                    <div className="text-gray-500">2-3x per day</div>
                  </div>
                  <div className="text-right">
                    <div className="text-green-400 font-bold">2PM, 8PM</div>
                    <div className="text-gray-600">Algorithm boost</div>
                  </div>
                </div>
                <div className="flex justify-between items-center p-3 rounded-lg bg-black/30 border border-gray-800">
                  <div>
                    <div className="text-white font-bold">Long-form</div>
                    <div className="text-gray-500">3x per week</div>
                  </div>
                  <div className="text-right">
                    <div className="text-green-400 font-bold">Weekends</div>
                    <div className="text-gray-600">Binge watching</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-12 text-center">
          <div className="glass-elite inline-block rounded-full px-8 py-4">
            <p className="text-gray-600 text-sm">
              <span className="text-cyan-400">ANYMS_AI</span> Elite Content System v3.0 | 
              <span className="text-purple-400"> 2025 Algorithm Optimized</span> | 
              <span className="text-pink-400"> Neural Engine Active</span>
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}
